import React,{Component} from 'react'
import Item from './item'

class Con extends Component{
    constructor(props){
        super(props);
        this.state = {
            num:this.props.list.length
        }
    }

    componentWillReceiveProps(nextProps,nextState){
        this.setState({
            num:Math.abs(this.props.list.length - nextProps.list.length)
        },() => {
            this.timer = setTimeout(() => {
                this.setState({
                    num:0
                })
            },3000)
        })
    }

    shouldComponentUpdata(nextProps,nextState){
        if(this.props.list.length === nextProps.list.length){
            //  && this.state.num === nextState.num
            return false
        }
        return true
    }

    render(){
        let {list} = this.props;
        let {num} = this.state;
        return (
            <div className="con">
                <div style={{display:num?'block':'none'}}>更新{num}数据</div>
                {list.map((item,index) => <Item item={item} key={index}/>)}
            </div>
        )
    }

    componentWillUnmount(){
        clearTimeout(this.timer);
    }
}

export default Con